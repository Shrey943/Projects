Group of 1:

- All orders are assumed to be limit (as instructed, it will take the input though).
- All orders are assumed to be indivisible (as instructed, it will take the input though).
